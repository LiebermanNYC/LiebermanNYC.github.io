//
//  AppDelegate.h
//  TestS
//
//  Created by Josh L on 11/7/14.
//  Copyright (c) 2014 JoshLieberman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

