## Readme
Please see CocoaAPI wrapper [README](https://github.com/soundcloud/CocoaSoundCloudAPI/blob/master/README.md)

## CocoaPods
[CocoaPods](http://cocoapods.org/) is a dependency manager for Xcode projects. 
You can include this SDK by adding following lines to your `Podfile`:

```
pod 'CocoaSoundCloudAPI', '1.0.2'
pod 'CocoaSoundCloudUI', '1.0.9'
```

and run the following command `pod install`.

## Contributing

Please create pull requests against the [develop](https://github.com/soundcloud/CocoaSoundCloudUI/tree/develop) branch as we cannot merge against master.
